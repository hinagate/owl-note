(() => {
  // src/lib/bookmarks.js
  var ROOT_TITLE = "\u{1F4D3} Notes";
  var OTHER_BOOKMARKS_ID = "2";
  function buildNoteUrl(payload) {
    return `chrome-extension://${chrome.runtime.id}/app.html#${payload}`;
  }
  var NOTE_URL_RE = /^chrome-extension:\/\/[a-p]{32}\/app\.html#([\s\S]*)$/;
  function isNoteUrl(url) {
    return typeof url === "string" && NOTE_URL_RE.test(url);
  }
  function payloadFromUrl(url) {
    const m = typeof url === "string" ? NOTE_URL_RE.exec(url) : null;
    return m ? m[1] : null;
  }
  async function getOtherBookmarksId() {
    const [treeRoot] = await chrome.bookmarks.getTree();
    const roots = treeRoot && treeRoot.children || [];
    const byType = roots.find((r) => r.folderType === "other");
    if (byType) return byType.id;
    return (roots[1] || roots[0] || { id: OTHER_BOOKMARKS_ID }).id;
  }
  var ROOT_ID_KEY = "owl:rootId";
  async function findFolderByTitle(title) {
    const [tree] = await chrome.bookmarks.getTree();
    let found = null;
    (function walk(node) {
      for (const c of node.children || []) {
        if (c.url) continue;
        if (!found && c.title === title) found = c.id;
        walk(c);
      }
    })(tree);
    return found;
  }
  async function ensureRoot() {
    const stored = (await chrome.storage.local.get(ROOT_ID_KEY))[ROOT_ID_KEY];
    if (stored) {
      try {
        const [node] = await chrome.bookmarks.get(stored);
        if (node && !node.url) return stored;
      } catch {
      }
    }
    let id = await findFolderByTitle(ROOT_TITLE);
    if (!id) {
      const otherId = await getOtherBookmarksId();
      const created = await chrome.bookmarks.create({ parentId: otherId, title: ROOT_TITLE });
      id = created.id;
    }
    await chrome.storage.local.set({ [ROOT_ID_KEY]: id });
    return id;
  }
  async function createNote(folderId, title, payload) {
    const node = await chrome.bookmarks.create({ parentId: folderId, title, url: buildNoteUrl(payload) });
    return node.id;
  }
  async function updateNote(bookmarkId, title, payload) {
    await chrome.bookmarks.update(bookmarkId, { title, url: buildNoteUrl(payload) });
  }
  async function deleteNote(bookmarkId) {
    await chrome.bookmarks.remove(bookmarkId);
  }

  // src/lib/base64url.js
  function bytesToBase64url(bytes) {
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function base64urlToBytes(str) {
    let s = str.replace(/-/g, "+").replace(/_/g, "/");
    const pad = s.length % 4 ? "=".repeat(4 - s.length % 4) : "";
    const bin = atob(s + pad);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  // src/lib/codec.js
  async function deflateRaw(str) {
    const cs = new CompressionStream("deflate-raw");
    const writer = cs.writable.getWriter();
    writer.write(new TextEncoder().encode(str));
    writer.close();
    const buf = await new Response(cs.readable).arrayBuffer();
    return new Uint8Array(buf);
  }
  async function inflateRaw(bytes) {
    const ds = new DecompressionStream("deflate-raw");
    const writer = ds.writable.getWriter();
    writer.write(bytes).catch(() => {
    });
    writer.close().catch(() => {
    });
    const buf = await new Response(ds.readable).arrayBuffer();
    return new TextDecoder().decode(buf);
  }
  async function encode(note) {
    const bytes = await deflateRaw(JSON.stringify(note));
    return bytesToBase64url(bytes);
  }
  async function decode(payload) {
    const json = await inflateRaw(base64urlToBytes(payload));
    return JSON.parse(json);
  }

  // src/lib/mirror.js
  var KEY = (id) => `note:${id}`;
  async function saveBackup(note, opts = {}) {
    const existing = (await chrome.storage.local.get(KEY(note.id)))[KEY(note.id)];
    const previous = existing ? existing.current : null;
    const folderId = opts.folderId ?? (existing ? existing.folderId : void 0);
    const localOnly = opts.localOnly ?? (existing ? !!existing.localOnly : false);
    await chrome.storage.local.set({ [KEY(note.id)]: { current: note, previous, folderId, localOnly } });
  }

  // src/lib/note.js
  function contentHash(str) {
    let h1 = 3735928559, h2 = 1103547991;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
  }
  function extractTitle(body) {
    for (const line of String(body).split("\n")) {
      const t = line.trim();
      if (!t) continue;
      return t.replace(/^#+\s*/, "").slice(0, 120) || "Untitled";
    }
    return "Untitled";
  }
  function createNote2({ title, body = "", attachments = [] } = {}) {
    return {
      id: crypto.randomUUID(),
      title: typeof title === "string" && title.trim() ? title : extractTitle(body),
      body,
      attachments,
      created: Date.now(),
      // recency key for newest-first sorting (survives reloads)
      version: 1,
      hash: contentHash(body)
    };
  }

  // src/lib/save-note.js
  var WARN_URL_BYTES = 16384;
  var MAX_URL_BYTES = 65536;
  function urlByteLength(payload) {
    return new TextEncoder().encode(buildNoteUrl(payload)).length;
  }
  async function saveNote(note, folderId, existingBookmarkId) {
    await saveBackup(note);
    const payload = await encode(note);
    const bytes = urlByteLength(payload);
    if (bytes > MAX_URL_BYTES) {
      if (existingBookmarkId) await deleteNote(existingBookmarkId);
      await saveBackup(note, { folderId, localOnly: true });
      return { bookmarkId: null, status: "capped" };
    }
    let bookmarkId = existingBookmarkId;
    if (bookmarkId) await updateNote(bookmarkId, note.title, payload);
    else bookmarkId = await createNote(folderId, note.title, payload);
    await saveBackup(note, { localOnly: false });
    return { bookmarkId, status: bytes > WARN_URL_BYTES ? "warn" : "ok" };
  }

  // src/lib/quick-note.js
  function buildQuickNote({ title = "", url = "", selection = "" } = {}) {
    const sel = String(selection ?? "").trim();
    const link = url ? `[${(title || url).trim()}](${url})` : "";
    const body = [sel, link].filter(Boolean).join("\n\n");
    return { title: String(title ?? "").trim(), body };
  }

  // src/background/service-worker.js
  var SAVE_SELECTION_ID = "owl-save-selection";
  async function handleInstalled() {
    await ensureRoot();
    chrome.contextMenus?.create({ id: SAVE_SELECTION_ID, title: "Save selection to OWL-Note", contexts: ["selection"] });
  }
  async function handleActionClick() {
    await chrome.tabs.create({ url: "app.html" });
  }
  async function handleSaveSelection(info, tab) {
    if (info.menuItemId !== SAVE_SELECTION_ID) return;
    const selection = (info.selectionText || "").trim();
    if (!selection) return;
    const url = info.pageUrl || tab && tab.url || "";
    const title = tab && tab.title || "";
    const { title: noteTitle, body } = buildQuickNote({ title, url, selection });
    const root = await ensureRoot();
    await saveNote(createNote2({ title: noteTitle, body }), root, void 0);
    await flashSaved();
  }
  async function flashSaved() {
    try {
      await chrome.action?.setBadgeText?.({ text: "\u2713" });
      await chrome.action?.setBadgeBackgroundColor?.({ color: "#2e7d32" });
      setTimeout(() => chrome.action?.setBadgeText?.({ text: "" }), 2e3);
    } catch {
    }
  }
  async function handleBookmarkChanged(id, changeInfo) {
    const url = changeInfo && changeInfo.url;
    if (!isNoteUrl(url)) return;
    try {
      const note = await decode(payloadFromUrl(url));
      await saveBackup(note);
    } catch {
    }
  }
  function wireEvents() {
    const c = typeof chrome !== "undefined" ? chrome : void 0;
    c?.runtime?.onInstalled?.addListener(handleInstalled);
    c?.action?.onClicked?.addListener(handleActionClick);
    c?.contextMenus?.onClicked?.addListener(handleSaveSelection);
    c?.bookmarks?.onChanged?.addListener(handleBookmarkChanged);
    c?.bookmarks?.onCreated?.addListener((id, node) => handleBookmarkChanged(id, { url: node.url }));
  }
  wireEvents();
})();
